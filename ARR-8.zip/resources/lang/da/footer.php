<?php

return [
    'services'=>'خدمات',
    'address'=>'ادرس',
    'relation'=>'روابط امور بین‌الملل',
    'exportation'=>'صادرات و سرمایه گذاری',
    'gov_relations'=>'روابط بادولت و خدمات حقوقی',
    'social_media'=>'شبکه های اجتماعی',
    'facebook'=>'فیسبوک',
    'instagram'=>'انستگرام',
    'twitter'=>'تویتر',
    'youtube'=>'یوتیوب',
];
