                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                2021 &copy; Developed By <a href="#">MASKHAN</a>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->