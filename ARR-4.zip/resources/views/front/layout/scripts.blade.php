
			<script src="{{asset('front_assets/js/vendor/bootstrap.min.js')}}"></script>			
			<script src="{{asset('front_assets/js/vendor/jquery-2.2.4.min.js')}}"></script>
			<script src="{{asset('front_assets/js/easing.min.js')}}"></script>			
			<script src="{{asset('front_assets/js/hoverIntent.js')}}"></script>
			<script src="{{asset('front_assets/js/superfish.min.js')}}"></script>	
			<script src="{{asset('front_assets/js/jquery.ajaxchimp.min.js')}}"></script>
			<script src="{{asset('front_assets/js/jquery.magnific-popup.min.js')}}"></script>	
    		<script src="{{asset('front_assets/js/jquery.tabs.min.js')}}"></script>						
			<script src="{{asset('front_assets/js/jquery.nice-select.min.js')}}"></script>	
			<script src="{{asset('front_assets/js/owl.carousel.min.js')}}"></script>									
			<script src="{{asset('front_assets/js/mail-script.js')}}"></script>	
			<script src="{{asset('front_assets/js/main.js')}}"></script>
			<script src="{{asset('front_assets/js/custom.js')}}"></script>
		