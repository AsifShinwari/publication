<b>{{ $name }}</b>,
<p>{!!$body!!}</p>