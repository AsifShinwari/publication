<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Session;
use Stripe;
use DB;
class StripeController extends Controller
{
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function stripe()
    {
        return view('stripe');
    }
   
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function stripePost(Request $request)
    {
        $email=$request->email;
        $total_amount=$request->amount;
        $tax=$total_amount*19/100;
        $net_pay=$total_amount+$tax;
    
        Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
       $result= Stripe\Charge::create([
                "amount" => (int)$net_pay,
                "currency" => "EUR",
                "source" => $request->stripeToken,
                "description" => $request->description,
        ]);
        
        if($result->status=='succeeded'){
            $res=[
                'transaction_id'=>$result->id,
                'amount'=>(int)$net_pay,
                'tax_applied'=>'19',
                'created'=>$result->created,
                'currency'=>$result->currency,
                'description'=>$result->description,
                'receipt_url'=>$result->receipt_url,
                'email'=>$request->email,
            ];

           $is_saved= DB::table('payments')->insert($res);
            
            $to_name = 'ESRO';
            $to_email = 'esro.europe@gmail.com';
            $data = array('name'=>"ESRO", 'body' => "Payment Transaction: <a href='".$result->receipt_url."'>Click Here For Payment Invoice</a>");

            Mail::send('mail', $data, function($message) use ($to_name, $to_email,$email) {
            $message->to($to_email, $to_name)
            ->subject('Charges Received!');
            $message->from('esro.europe@app.com','Charges Received From '.$email);
            });

            $to_name = 'ESRO Payments';
            $to_email = $request->email;
            $data = array('name'=>"ESRO", 'body' => "Payment Transaction: <a href='".$result->receipt_url."'>Click Here For Payment Invoice</a>");

            Mail::send('mail', $data, function($message) use ($to_name, $to_email,$email) {
            $message->to($to_email, $to_name)
            ->subject('Charges Received!');
            $message->from('esro.europe@app.com','Charges Received From '.$email);
            });

            Session::flash('success', 'Payment successful!');
           
            return back();
        }
   
        
    }
}
