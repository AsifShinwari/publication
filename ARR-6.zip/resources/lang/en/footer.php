<?php

return [
    'services'=>'Services',
    'address'=>'Address',
    'relation'=>'International Affairs Relations',
    'exportation'=>'Export and investment',
    'gov_relations'=>'Government relations and legal services',
    'social_media'=>'Social Networks',
    'facebook'=>'Facebook',
    'instagram'=>'Instagram',
    'twitter'=>'Twitter',
    'youtube'=>'Youtube',
];
