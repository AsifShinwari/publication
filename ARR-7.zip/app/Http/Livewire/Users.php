<?php

namespace App\Http\Livewire;
use Livewire\Component;
use Livewire\WithPagination;

use DB;


class Users extends Component
{
    use WithPagination;


    public $username;
    public $email;
    public $password;
    public $type;
    public $selected_id;

    public function submit($data){

        $this->username=$data['username'];
        $this->email=$data['email'];
        $this->type=$data['type'];
        $this->password=$data['password'];
        
        $this->validate([
            'username' => 'required',
            'email' => 'required|unique:users',
            'type' => 'required',
            'password' => 'required|min:6',
        ]);

        DB::table('users')->insert([
            'name'=>$data['username'],
            'email'=>$data['email'],
            'type'=>$data['type'],
            'password'=>$data['password'],
        ]);
        session()->flash('inserted', 'New User Successfully Added!');
        $this->render();
        $this->resetPage();
    }

    public function edit($id){
        $this->selected_id=$id;
        $user=DB::table('users')->where('id',$id)->first();
        $this->username=$user->name;
        $this->email=$user->email;
        $this->type=$user->type;
        $this->password='';
    }

    public function update($data){

        $this->username=$data['username'];
        $this->email=$data['email'];
        $this->type=$data['type'];
        $this->password=$data['password'];

    
        
        if($this->selected_id){

        $user=DB::table('users')->where('id',$this->selected_id)->first();

        if($user->email==$this->email){

            $this->validate([
                'username' => 'required',
                'type' => 'required',
                'password' => 'required|min:6',
            ]);

        }else{
            $this->validate([
                'username' => 'required',
                'type' => 'required',
                'email' => 'required|unique:users',
                'password' => 'required|min:6',
            ]);
        }
        DB::table('users')->where('id',$this->selected_id)->update([
            'name'=>$this->username,
            'type'=>$this->type,
            'email'=>$this->email,
            'password'=>$this->password,
        ]);

        }
        session()->flash('updated', 'User Updated Successfully!');
        $this->render();
        $this->resetPage();

    }

    public function delete(){
        $this->validate(['selected_id' => 'required']);
        DB::table('users')->where('id',$this->selected_id)->delete();
        session()->flash('deleted', 'User Deleted Successfully!');
        $this->render();
        $this->resetPage();
    }
    public function render()
    {
        $users=DB::table('users')->orderBy('id','desc')->paginate(5);
        return view('livewire.users',compact('users'))
        ->layout('home')->slot('slot');
    }
}
