<?php

return [
    'home'=>'صفحه اصلی',
    'about_us'=>'درباره ما',
    'team_members'=>'اعضاٍ تیم',
    'mission'=>'ماموریت',
    'org_structure'=>'ساختار اعضا اطاق',
    'vision'=>'چشم انداز',
    'history'=>'تاریخچه',
    'membership'=>'عضویت',
    'add_membership'=>'درخواستی عضویت',
    'all_membership'=>'درخواستی ها',
    'news'=>'اخبار',
    'general_news'=>'خبرها عمومی',
    'provincial_news'=>'خبرهای اطاق ولایتی',
    'member_org'=>'شراکت',
    'events'=>'رویداد ها',
    'comming_events'=>'رویداد های اینده',
    'all_events'=>'تمام رویداد ها',
    'gallery'=>'گالری',
    'gallery_pictures'=>'تصاویر',
    'gallery_videos'=>'ویدیو ها',
    'contact_us'=>'تماس با ما',
    'sidebar'=>'مینو',
    'main_title'=>'اتاق تولیدات زارعت و مالداری افغانستان',

];
