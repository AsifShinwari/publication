<?php

return [
    'home'=>'اصلي صفحه',
    'about_us'=>'زموږ په اړه',
    'team_members'=>'د ټیم غړي',
    'mission'=>'زموږ ماموریت',
    'org_structure'=>'اطاق غویو جوړښت',
    'vision'=>'لیدلوری',
    'history'=>'تاریخچه',
    'membership'=>'غړیتوب',
    'add_membership'=>'غړیتوب غوښتنلیک',
    'all_membership'=>'غړیتوب غوښتنلیکونه',
    'news'=>'خبرونه',
    'general_news'=>'عمومي خبرونه',
    'provincial_news'=>'د ولایتي خونو خبرونه',
    'member_org'=>'شراکت',
    'events'=>'پیښې',
    'comming_events'=>'راتلونکی پیښې',
    'all_events'=>'ټولی پیښې',
    'gallery'=>'ګالري',
    'gallery_pictures'=>'انځورونه',
    'gallery_videos'=>'ويډیوګانی',
    'contact_us'=>'اړیکه نیول',
    'sidebar'=>'مینو',
    'main_title'=>'د افغانستان د کرنې او مالدارۍ تولید اطاق',

];
