<?php

return [
    'services'=>'خدمات',
    'address'=>'ادرس',
    'relation'=>'د نړیوالو چارو اړیکې',
    'exportation'=>'صادرات او پانګونه',
    'gov_relations'=>'د حکومت اړیکې او قانوني خدمتونه',
    'social_media'=>'ټولنیزې شبکې',
    'facebook'=>'فیسبوک',
    'instagram'=>'انستګرام',
    'twitter'=>'ټویټر',
    'youtube'=>'یوټیوب',
];
