<?php

return [

    'home'=>'Home',
    'about_us'=>'About Us',
    'team_members'=>'Team Members',
    'mission'=>'Our Mission',
    'org_structure'=>'Organization Structure',
    'vision'=>'Our Vision',
    'history'=>'History',
    'membership'=>'Membership',
    'add_membership'=>'Memebership Application',
    'all_membership'=>'Membership Applications',
    'news'=>'News',
    'general_news'=>'All News',
    'provincial_news'=>'Provincial News',
    'member_org'=>'Partners',
    'events'=>'Events',
    'comming_events'=>'Comming Events',
    'all_events'=>'All Events',
    'gallery'=>'Gallery',
    'gallery_pictures'=>'Pictures',
    'gallery_videos'=>'Videos',
    'contact_us'=>'Contact Us',
    'sidebar'=>'Sidebar',
    'main_title'=>'Afghanistan Chamber of Agriculture and Livestock Production',
];
